// Calculator
 #include "stdio.h"
 #include "ctype.h"
 #include "string.h"
 #include "math.h"

 double calculate(double first_value, double second_value, char operator) {
     switch (operator) {
         case '+': return first_value + second_value;
         case '-': return first_value - second_value;
         case '*': return first_value * second_value;
         case '/': return first_value / second_value;
         case '^': return pow(first_value, second_value);
         case '%': return fmod(first_value, second_value);
         default: return 0;
     }
 }

 double evaluate_expression(char* expression) {
     double values_stack[100];
     char operators_stack[100];
     int values_index = -1, operators_index = -1;

     for (int i = 0; i < strlen(expression); i++) {
         if (isdigit(expression[i])) {
             double number = 0;
             while (i < strlen(expression) && isdigit(expression[i])) {
                 number = number * 10 + (expression[i] - '0');
                 i++;
             }
             if (i < strlen(expression) && expression[i] == '.') {
                 double decimal_part = 0.0;
                 double decimal_place = 10.0;
                 i++;
                 while (i < strlen(expression) && isdigit(expression[i])) {
                     decimal_part += (expression[i] - '0') / decimal_place;
                     decimal_place *= 10;
                     i++;
                 }
                 number += decimal_part;
             }
             values_stack[++values_index] = number;
             i--;
         } else if (expression[i] == '(') {
             operators_stack[++operators_index] = expression[i];
         } else if (expression[i] == ')') {
             while (operators_index != -1 && operators_stack[operators_index] != '(') {
                 double second_value = values_stack[values_index--];
                 double first_value = values_stack[values_index--];
                 char operator = operators_stack[operators_index--];
                 values_stack[++values_index] = calculate(first_value, second_value, operator);
             }
             operators_index--;
         } else if (strchr("+-*/^%", expression[i])) {
             while (operators_index != -1 && strchr("+-*/^%", operators_stack[operators_index])
                 && strchr("+-*/^%", operators_stack[operators_index]) >= strchr("+-*/^%", expression[i])) {
                 double second_value = values_stack[values_index--];
                 double first_value = values_stack[values_index--];
                 char operator = operators_stack[operators_index--];
                 values_stack[++values_index] = calculate(first_value, second_value, operator);
             }
             operators_stack[++operators_index] = expression[i];
         }
     }

     while (operators_index != -1) {
         double second_value = values_stack[values_index--];
         double first_value = values_stack[values_index--];
         char operator = operators_stack[operators_index--];
         values_stack[++values_index] = calculate(first_value, second_value, operator);
     }

     return values_stack[values_index];
 }

 void run_calculator() {
     char input_expression[100];

     while (1) {
         printf("Enter the operation (or type 'exit' to quit): ");
         scanf("%s", input_expression);

         if (strcmp(input_expression, "exit") == 0) {
             break;
         }

        double result = evaluate_expression(input_expression);
         printf("Result: %lf\n", result);
     }
 }

 int main() {
     run_calculator();
     printf("Calculator has been exited.\n");
     return 0;
 }


// // Milliy taomlar menyusi
// #include "stdio.h"
//
// int main() {
//     int section, dish, quantity, total_price = 0;
//     int choice = 1;
//
//     printf("Assalamu 'alaykum! Karavansaray restoraniga hush kelibsiz!\n");
//
//     while (choice) {
//         printf("\nBo'limlarni tanlang:\n");
//         printf("1. Issiq taomlar\n2. Salatlar\n3. Ichimliklar\n4. Desertlar\n5. Nonlar\n");
//         scanf("%d", &section);
//
//         switch (section) {
//             case 1:
//                 printf("Issiq taomlar:\n");
//                 printf("1. Osh - 30,000 so'm\n2. Somsa - 15,000 so'm\n3. Manti - 25,000 so'm\n4. Xonim - 30,000 so'm\n");
//                 printf("5. Sho'rva - 28,000 so'm\n6. Lag'mon sho'rva - 30,000 so'm\n7. No'xat sho'rva - 32,000 so'm\n");
//                 printf("8. Qovurma lag'mon - 25,000 so'm\n9. Shashlik mol go'shtli - 80,000 so'm\n");
//                 printf("10. Shashlik tovuq go'shtli - 50,000 so'm\n11. Qiymali shashlik - 60,000 so'm\n");
//                 printf("12. Qozon kabob - 120,000 so'm\n13. Norin - 90,000 so'm\n14. Beshbarmoq - 200,000 so'm\n");
//                 printf("15. Mastava - 20,000 so'm\n16. Moshxo'rda - 15,000 so'm\n17. Jizz - 180,000 so'm\n");
//                 printf("18. Do'lma - 40,000 so'm\n19. Jarkob - 55,000 so'm\n20. Halim - 35,000 so'm\n");
//                 scanf("%d", &dish);
//                 printf("Nechta?\n");
//                 scanf("%d", &quantity);
//
//                 switch (dish) {
//                     case 1: total_price += 30000 * quantity; break;
//                     case 2: total_price += 15000 * quantity; break;
//                     case 3: total_price += 25000 * quantity; break;
//                     case 4: total_price += 30000 * quantity; break;
//                     case 5: total_price += 28000 * quantity; break;
//                     case 6: total_price += 30000 * quantity; break;
//                     case 7: total_price += 32000 * quantity; break;
//                     case 8: total_price += 25000 * quantity; break;
//                     case 9: total_price += 80000 * quantity; break;
//                     case 10: total_price += 50000 * quantity; break;
//                     case 11: total_price += 60000 * quantity; break;
//                     case 12: total_price += 120000 * quantity; break;
//                     case 13: total_price += 90000 * quantity; break;
//                     case 14: total_price += 200000 * quantity; break;
//                     case 15: total_price += 20000 * quantity; break;
//                     case 16: total_price += 15000 * quantity; break;
//                     case 17: total_price += 180000 * quantity; break;
//                     case 18: total_price += 40000 * quantity; break;
//                     case 19: total_price += 55000 * quantity; break;
//                     case 20: total_price += 35000 * quantity; break;
//                 }
//                 break;
//
//             case 2:
//                 printf("Salatlar:\n");
//                 printf("1. Achchiq chuchuk - 25,000 so'm\n2. Tomchi - 22,000 so'm\n3. Smak - 30,000 so'm\n");
//                 printf("4. Olivie - 32,000 so'm\n5. Sezar - 35,000 so'm\n6. Fantaziya - 40,000 so'm\n");
//                 printf("7. Bahor - 28,000 so'm\n8. Pikantiy - 42,000 so'm\n9. Damskiy Kapriz - 38,000 so'm\n10. Ledi - 32,000 so'm\n");
//                 scanf("%d", &dish);
//                 printf("Nechta?\n");
//                 scanf("%d", &quantity);
//
//                 switch (dish) {
//                     case 1: total_price += 25000 * quantity; break;
//                     case 2: total_price += 22000 * quantity; break;
//                     case 3: total_price += 30000 * quantity; break;
//                     case 4: total_price += 32000 * quantity; break;
//                     case 5: total_price += 35000 * quantity; break;
//                     case 6: total_price += 40000 * quantity; break;
//                     case 7: total_price += 28000 * quantity; break;
//                     case 8: total_price += 42000 * quantity; break;
//                     case 9: total_price += 38000 * quantity; break;
//                     case 10: total_price += 32000 * quantity; break;
//                 }
//                 break;
//
//             case 3:
//                 printf("Ichimliklar:\n");
//                 printf("1. Ko'k choy - 5,000 so'm\n2. Qora choy - 5,000 so'm\n3. Giyohli choy - 7,000 so'm\n");
//                 printf("4. Limon choy - 8,000 so'm\n5. Namatakli choy - 10,000 so'm\n6. Qora Coffee - 15,000 so'm\n");
//                 printf("7. Sutli coffee - 12,000 so'm\n8. Turk coffee - 20,000 so'm\n9. Coca-Cola - 15,000 so'm\n");
//                 printf("10. Pepsi - 15,000 so'm\n11. Fanta - 15,000 so'm\n12. Mirinda - 15,000 so'm\n");
//                 printf("13. Yaxna choy - 14,000 so'm\n14. Bez gaz suv - 10,000 so'm\n15. Gazlangan suv - 12,000 so'm\n");
//                 printf("16. Olmali sok - 18,000 so'm\n17. O'rikli sok - 18,000 so'm\n18. Anorli sok - 18,000 so'm\n");
//                 printf("19. Ananasli sok - 18,000 so'm\n20. Multifruit sok - 20,000 so'm\n");
//                 scanf("%d", &dish);
//                 printf("Nechta?\n");
//                 scanf("%d", &quantity);
//
//                 switch (dish) {
//                     case 1: total_price += 5000 * quantity; break;
//                     case 2: total_price += 5000 * quantity; break;
//                     case 3: total_price += 7000 * quantity; break;
//                     case 4: total_price += 8000 * quantity; break;
//                     case 5: total_price += 10000 * quantity; break;
//                     case 6: total_price += 15000 * quantity; break;
//                     case 7: total_price += 12000 * quantity; break;
//                     case 8: total_price += 20000 * quantity; break;
//                     case 9: total_price += 15000 * quantity; break;
//                     case 10: total_price += 15000 * quantity; break;
//                     case 11: total_price += 15000 * quantity; break;
//                     case 12: total_price += 15000 * quantity; break;
//                     case 13: total_price += 14000 * quantity; break;
//                     case 14: total_price += 10000 * quantity; break;
//                     case 15: total_price += 12000 * quantity; break;
//                     case 16: total_price += 18000 * quantity; break;
//                     case 17: total_price += 18000 * quantity; break;
//                     case 18: total_price += 18000 * quantity; break;
//                     case 19: total_price += 18000 * quantity; break;
//                     case 20: total_price += 20000 * quantity; break;
//                 }
//                 break;
//
//             case 4:
//                 printf("Desertlar:\n");
//                 printf("1. Medovik - 22,000 so'm\n2. Chizkeyk - 26,000 so'm\n3. Merengali rulet - 18,000 so'm\n");
//                 printf("4. Brauli pirogi - 30,000 so'm\n5. Tiramisu - 28,000 so'm\n6. Xandon pista - 32,000 so'm\n");
//                 printf("7. New York - 24,000 so'm\n8. Snickers - 40,000 so'm\n9. Baklava - 38,000 so'm\n10. Muzqaymoq - 15,000 so'm\n");
//                 scanf("%d", &dish);
//                 printf("Nechta?\n");
//                 scanf("%d", &quantity);
//
//                 switch (dish) {
//                     case 1: total_price += 22000 * quantity; break;
//                     case 2: total_price += 26000 * quantity; break;
//                     case 3: total_price += 18000 * quantity; break;
//                     case 4: total_price += 30000 * quantity; break;
//                     case 5: total_price += 28000 * quantity; break;
//                     case 6: total_price += 32000 * quantity; break;
//                     case 7: total_price += 24000 * quantity; break;
//                     case 8: total_price += 40000 * quantity; break;
//                     case 9: total_price += 38000 * quantity; break;
//                     case 10: total_price += 15000 * quantity; break;
//                 }
//                 break;
//
//             case 5:
//                 printf("Nonlar:\n");
//                 printf("1. Shirmoy Non - 7,000 so'm\n2. Yuz Patir - 16,000 so'm\n3. Qatlama - 10,000 so'm\n");
//                 printf("4. Qaymoqli Non - 18,000 so'm\n5. Jizzali Non - 12,000 so'm\n6. Kulcha non - 8,000 so'm\n");
//                 printf("7. Tandir non - 10,000 so'm\n8. Lochira non - 14,000 so'm\n9. Buxoro noni - 12,000 so'm\n10. Samarqand noni - 10,000 so'm\n");
//                 scanf("%d", &dish);
//                 printf("Nechta?\n");
//                 scanf("%d", &quantity);
//
//                 switch (dish) {
//                     case 1: total_price += 7000 * quantity; break;
//                     case 2: total_price += 16000 * quantity; break;
//                     case 3: total_price += 10000 * quantity; break;
//                     case 4: total_price += 18000 * quantity; break;
//                     case 5: total_price += 12000 * quantity; break;
//                     case 6: total_price += 8000 * quantity; break;
//                     case 7: total_price += 10000 * quantity; break;
//                     case 8: total_price += 14000 * quantity; break;
//                     case 9: total_price += 12000 * quantity; break;
//                     case 10: total_price += 10000 * quantity; break;
//                 }
//                 break;
//
//             default:
//                 printf("Noto'g'ri tanlov!\n");
//                 break;
//         }
//
//         printf("Yana biror narsa buyurtma qilasizmi? (1 - Ha, 0 - Yo'q)\n");
//         scanf("%d", &choice);
//     }
//
//     printf("\nSizning buyurtmangizning (narxi) umumiy qiymati: %d so'm\n", total_price);
//     printf("Yoqimli ishtaha! Sizni yana Karavansaray restoranida kutib qolamiz.\nTashrifingiz uchun tashakkur!\n");
//
//     return 0;
// }
//
//
//
//
